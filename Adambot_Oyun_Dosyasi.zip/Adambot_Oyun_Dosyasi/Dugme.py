import pygame
from Yazi import *

pygame.init()

class Dugme:
    def __init__(self, x, y, genislik, yukseklik, renk, yazi):
        self.x, self.y, self.genislik, self.yukseklik, self.renk, self.yazi = x, y, genislik, yukseklik, renk, Yazi(x + genislik/2, y + yukseklik/4, yukseklik//2, yazi)
        
    def ekrana_ciz(self, pencere):
        pygame.draw.rect(pencere, self.renk, pygame.Rect(self.x, self.y, self.genislik, self.yukseklik))
        self.yazi.ekrana_ciz(pencere)
        
    def tiklama_kontrolu(self, tiklama_pozisyonu):
        if tiklama_pozisyonu[0] > self.x and tiklama_pozisyonu[0] < self.x + self.genislik:
            if tiklama_pozisyonu[1] > self.y and tiklama_pozisyonu[1] < self.y + self.yukseklik:
                return True
        return False
