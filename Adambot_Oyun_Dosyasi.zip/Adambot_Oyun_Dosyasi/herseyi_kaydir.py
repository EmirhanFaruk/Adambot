def herseyi_kaydir(adambot, monitor_buyuklugu, patlamalar, tanklar, zeminler, bombalar):
    if not(adambot.x < monitor_buyuklugu[0]*3/4 and adambot.x > monitor_buyuklugu[0]/4):
        #if adambot.x < monitor_buyuklugu[0]/4:
        adambot.x -= adambot.ivme[0]
        for patlama in patlamalar:
            patlama.x -= adambot.ivme[0]
        for tank in tanklar:
            tank.x -= adambot.ivme[0]
        for zemin in zeminler:
            zemin.x -= adambot.ivme[0]
        for bomba in bombalar:
            bomba.x -= adambot.ivme[0]
    if not(adambot.y < monitor_buyuklugu[1]*3/4 and adambot.y > monitor_buyuklugu[1]/4):
        adambot.y -= adambot.ivme[1]
        for patlama in patlamalar:
            patlama.y -= adambot.ivme[1]
        for tank in tanklar:
            tank.y -= adambot.ivme[1]
        for zemin in zeminler:
            zemin.y -= adambot.ivme[1]
        for bomba in bombalar:
            bomba.y -= adambot.ivme[1]
    return adambot, patlamalar, tanklar, zeminler, bombalar

