import pygame
from math import sqrt
from random import choice, randint, uniform


pygame.init()

class Cekicadam_Gizli_AntiHava_Savunmasi:
    def __init__(self, x, y, genislik, yukseklik, hasar, ates_hizi, menzil):
        return
